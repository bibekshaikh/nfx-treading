NFX Treading — Updated English Demo

Contents:
- index.html: responsive English-language front-end preview
- nfx-banner-reference.jpg: retained reference banner

Included preview features:
- Registration and login preview forms
- Country calling-code selector (loads from a third-party CDN; internet required)
- Starter, Premium, Pro and VIP plan cards with three named sub-plan tiers each
- 180-day validity labels and India-time calendar-day clock preview
- Deposit and withdrawal preview forms
- Minimum withdrawal: 50 USDT; preview fee: 7%; net amount calculation
- Withdraw policy: any time; processing up to 24 hours
- Telegram channel: https://t.me/NFXtreading
- Telegram support bot: https://t.me/NFXTreadingSupportBot
- Admin panel visual preview available using the URL fragment #admin-preview

IMPORTANT LIMITATIONS:
This ZIP is a static front-end demonstration only. It has no real user database, authentication, secure administrator roles, member search, profile editing, payment verification, deposit/withdrawal processing, wallet ledger, plan purchase, investment, daily profit, referral payouts, KYC storage, or server-side audit log. Admin preview controls and statuses are local visual demonstrations only. The #admin-preview fragment is NOT secure access control. Do not enter real passwords, OTPs, personal data, or send cryptocurrency to any displayed demo address.

Real account and payment functionality requires a separately designed secure backend, database, server-side authorization, audit logging, payment verification, and applicable legal/regulatory review. Never embed administrator passwords or API secrets in this ZIP.
